﻿
using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Controllers;
using RaceDay.Data;

namespace RaceDay_Test
{
    public static class TestHelper
    {
        public static RaceDayDbContext CreateDatabase()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        public static AuthController CreateController(RaceDayDbContext db)
        {
            var settings = new System.Collections.Generic.Dictionary<string, string?>
            {
                { "Jwt:Key", "RaceDayTestSecretKey12345678901234567890" },
                { "Jwt:Issuer", "RaceDayTests" },
                { "Jwt:Audience", "RaceDayTests" }
            };

            var configuration = new ConfigurationBuilder()
                .AddInMemoryCollection(settings)
                .Build();

            var services = new ServiceCollection();
            services.AddSingleton<IConfiguration>(configuration);

            var provider = services.BuildServiceProvider();

            var controller = new AuthController(db);

            controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext
                {
                    RequestServices = provider
                }
            };

            return controller;
        }
    }
}
