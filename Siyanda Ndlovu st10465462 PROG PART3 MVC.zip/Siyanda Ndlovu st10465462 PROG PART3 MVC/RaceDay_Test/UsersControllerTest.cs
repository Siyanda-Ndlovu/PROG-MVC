﻿using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Data;
using RaceDayPOE_part2.Controllers;
using RaceDayPOE_part2.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace RaceDay_Test
{
    public class UsersControllerTest
    {

        // Create a temporary database for each test
        private RaceDayDbContext CreateDatabase()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        // TEST 1: Existing user
        [Fact]
        public async Task GetProfile_ExistingUser_ReturnsOk()
        {
            using var db = CreateDatabase();

            var user = new Users
            {
                name = "Test User",
                phoneNumber = "0712345678",
                email = "test@example.com",
                password = "TestHashedPassword",
                role = "Participant"
            };

            db.Users.Add(user);
            await db.SaveChangesAsync();

            var controller = new UsersController(db);

            var result = await controller.GetProfile(user.user_ID);

            Assert.IsType<OkObjectResult>(result);
        }

        // TEST 2: User does not exist
        [Fact]
        public async Task GetProfile_UserNotFound_ReturnsNotFound()
        {
            using var db = CreateDatabase();

            var controller = new UsersController(db);

            var result = await controller.GetProfile(99999);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        // TEST 3: Profile must not expose password
        [Fact]
        public async Task GetProfile_DoesNotReturnPassword()
        {
            using var db = CreateDatabase();

            var user = new Users
            {
                name = "Test User",
                phoneNumber = "0712345678",
                email = "test@example.com",
                password = "TestHashedPassword",
                role = "Participant"
            };

            db.Users.Add(user);
            await db.SaveChangesAsync();

            var controller = new UsersController(db);

            var result = await controller.GetProfile(user.user_ID);

            var okResult = Assert.IsType<OkObjectResult>(result);

            var returnedProperties = okResult.Value!
                .GetType()
                .GetProperties()
                .Select(p => p.Name)
                .ToList();

            Assert.DoesNotContain(
                returnedProperties,
                p => p.Equals("password",
                    StringComparison.OrdinalIgnoreCase));
        }

    }
}
