﻿using Xunit;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using RaceDay.Controllers;
using RaceDay.Data;
using RaceDayPOE_part2.DTOs;
using RaceDayPOE_part2.Models;

namespace RaceDay_Test;

public class AuthControllerTests
{
    [Fact]
    public async Task Register_EmptyFields_ReturnsBadRequest()
    {
        using var db = TestHelper.CreateDatabase(); var controller = new AuthController(db);
        var result = await controller.Register(new RegisterDto()); Assert.IsType<BadRequestObjectResult>(result);
    }
    [Fact]
    public async Task Register_InvalidRole_ReturnsBadRequest()
    {
        using var db = TestHelper.CreateDatabase(); var controller = new AuthController(db);
        var result = await controller.Register(new RegisterDto { Name = "Test", PhoneNumber = "0123456789", Email = "test@example.com", Password = "password123", Role = "Admin" });
        Assert.IsType<BadRequestObjectResult>(result);
    }
    [Fact]
    public async Task Login_EmptyCredentials_ReturnsBadRequest()
    {
        using var db = TestHelper.CreateDatabase(); var controller = new AuthController(db);
        Assert.IsType<BadRequestObjectResult>(await controller.Login(new LoginDto()));
    }
    [Fact]
    public async Task Login_UnknownEmail_ReturnsUnauthorized()
    {
        using var db = TestHelper.CreateDatabase(); var controller = new AuthController(db);
        Assert.IsType<UnauthorizedObjectResult>(await controller.Login(new LoginDto { Email = "unknown@example.com", Password = "wrong" }));
    }
}
