using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;
namespace RaceDay_MVC.Services;
public class RaceDayApi
{
    private readonly HttpClient _http;
    private readonly IHttpContextAccessor? _unused;
    public RaceDayApi(HttpClient http) { _http = http; }
    public async Task<(bool ok, JsonNode? data, string error)> Send(HttpContext context, HttpMethod method, string path, object? body = null)
    {
        try
        {
            using var request = new HttpRequestMessage(method, path);
            var token = context.Session.GetString("Token");
            if (!string.IsNullOrEmpty(token)) request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            if (body != null) request.Content = new StringContent(System.Text.Json.JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");
            using var response = await _http.SendAsync(request);
            var raw = await response.Content.ReadAsStringAsync();
            JsonNode? data = null;
            try { if (!string.IsNullOrWhiteSpace(raw)) data = JsonNode.Parse(raw); } catch { }
            return (response.IsSuccessStatusCode, data, response.IsSuccessStatusCode ? "" : $"API returned {(int)response.StatusCode}: {raw}");
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        { return (false, null, "Cannot connect to the API. Start RaceDayPOE_part2 first and verify the API address. " + ex.Message); }
    }
}
