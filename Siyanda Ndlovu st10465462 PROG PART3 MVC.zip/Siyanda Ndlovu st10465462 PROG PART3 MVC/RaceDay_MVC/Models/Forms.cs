using System.ComponentModel.DataAnnotations;
namespace RaceDay_MVC.Models;
public class LoginForm { [Required,EmailAddress] public string Email {get;set;}=""; [Required,DataType(DataType.Password)] public string Password {get;set;}=""; }
public class RegisterForm { [Required] public string Name {get;set;}=""; [Required] public string PhoneNumber {get;set;}=""; [Required,EmailAddress] public string Email {get;set;}=""; [Required,MinLength(6),DataType(DataType.Password)] public string Password {get;set;}=""; [Required] public string Role {get;set;}="Participant"; }
public class EventForm { [Required] public string event_name {get;set;}=""; [Required] public string location {get;set;}=""; [Range(1,int.MaxValue)] public int organiser_ID {get;set;} [Range(1,int.MaxValue)] public int category_ID {get;set;} }
public class CategoryForm { [Required] public string categoryName {get;set;}=""; public decimal? distance {get;set;} public TimeOnly? StartTime {get;set;} }
public class ResultForm { [Range(1,int.MaxValue)] public int enrolment_ID {get;set;} public int? position {get;set;} public TimeOnly? finishingTime {get;set;} }
