using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Services;
namespace RaceDay_MVC.Controllers;
public class EnrolmentsController:Controller
{
 private readonly RaceDayApi _api;public EnrolmentsController(RaceDayApi api)=>_api=api;
 public async Task<IActionResult> Index(){if(string.IsNullOrEmpty(HttpContext.Session.GetString("Token")))return RedirectToAction("Login","Account");var r=await _api.Send(HttpContext,HttpMethod.Get,"api/Enrolments");ViewBag.Error=r.error;return View(r.data);}
}
