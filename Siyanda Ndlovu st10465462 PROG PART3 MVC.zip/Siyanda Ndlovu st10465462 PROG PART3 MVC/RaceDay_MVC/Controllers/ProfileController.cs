using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Services;
namespace RaceDay_MVC.Controllers;
public class ProfileController:Controller
{
 private readonly RaceDayApi _api;public ProfileController(RaceDayApi api)=>_api=api;
 public async Task<IActionResult> Index(){var id=HttpContext.Session.GetString("UserId");if(string.IsNullOrEmpty(id))return RedirectToAction("Login","Account");var r=await _api.Send(HttpContext,HttpMethod.Get,$"api/Users/{id}");ViewBag.Error=r.error;return View(r.data);}
}
