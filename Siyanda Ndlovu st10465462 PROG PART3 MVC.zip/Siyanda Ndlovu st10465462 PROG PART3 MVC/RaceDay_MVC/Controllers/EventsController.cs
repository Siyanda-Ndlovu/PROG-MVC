using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Services;
using RaceDay_MVC.Models;
namespace RaceDay_MVC.Controllers;
public class EventsController:Controller
{
 private readonly RaceDayApi _api; public EventsController(RaceDayApi api)=>_api=api;
 private bool Logged()=>!string.IsNullOrEmpty(HttpContext.Session.GetString("Token"));
 private bool Organiser()=>HttpContext.Session.GetString("Role")=="Organiser";
 public async Task<IActionResult> Index(){if(!Logged())return RedirectToAction("Login","Account");var r=await _api.Send(HttpContext,HttpMethod.Get,"api/Events");ViewBag.Error=r.error;return View(r.data);}
 public async Task<IActionResult> Details(int id){if(!Logged())return RedirectToAction("Login","Account");var r=await _api.Send(HttpContext,HttpMethod.Get,$"api/Events/{id}");ViewBag.Error=r.error;return View(r.data);}
 public async Task<IActionResult> Create(){if(!Organiser())return Forbid();var r=await _api.Send(HttpContext,HttpMethod.Get,"api/Categories");ViewBag.Categories=r.data;return View(new EventForm());}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Create(EventForm form){if(!Organiser())return Forbid();if(!ModelState.IsValid){var c=await _api.Send(HttpContext,HttpMethod.Get,"api/Categories");ViewBag.Categories=c.data;return View(form);}var r=await _api.Send(HttpContext,HttpMethod.Post,"api/Events",form);if(r.ok)return RedirectToAction(nameof(Index));ViewBag.Error=r.error;var cats=await _api.Send(HttpContext,HttpMethod.Get,"api/Categories");ViewBag.Categories=cats.data;return View(form);}
 public async Task<IActionResult> Edit(int id){if(!Organiser())return Forbid();var r=await _api.Send(HttpContext,HttpMethod.Get,$"api/Events/{id}");if(!r.ok)return NotFound();var c=await _api.Send(HttpContext,HttpMethod.Get,"api/Categories");ViewBag.Categories=c.data;ViewBag.EventId=id;return View("Create",new EventForm {event_name=r.data?["event_name"]?.ToString()??"",location=r.data?["location"]?.ToString()??"",organiser_ID=int.TryParse(r.data?["organiser_ID"]?.ToString(),out var o)?o:0,category_ID=int.TryParse(r.data?["category_ID"]?.ToString(),out var cat)?cat:0});}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Edit(int id,EventForm form){if(!Organiser())return Forbid();if(!ModelState.IsValid){ViewBag.EventId=id;var c=await _api.Send(HttpContext,HttpMethod.Get,"api/Categories");ViewBag.Categories=c.data;return View("Create",form);}var r=await _api.Send(HttpContext,HttpMethod.Put,$"api/Events/{id}",form);if(r.ok)return RedirectToAction(nameof(Index));ViewBag.Error=r.error;ViewBag.EventId=id;var cats=await _api.Send(HttpContext,HttpMethod.Get,"api/Categories");ViewBag.Categories=cats.data;return View("Create",form);}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Delete(int id){if(!Organiser())return Forbid();var r=await _api.Send(HttpContext,HttpMethod.Delete,$"api/Events/{id}");TempData[r.ok?"Message":"Error"]=r.ok?"Event deleted.":r.error;return RedirectToAction(nameof(Index));}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Enter(int id){if(HttpContext.Session.GetString("Role")!="Participant")return Forbid();var r=await _api.Send(HttpContext,HttpMethod.Post,"api/Enrolments",new {event_ID=id,participantID=0});TempData[r.ok?"Message":"Error"]=r.ok?"Enrolled successfully.":r.error;return RedirectToAction(nameof(Details),new{id});}
}
