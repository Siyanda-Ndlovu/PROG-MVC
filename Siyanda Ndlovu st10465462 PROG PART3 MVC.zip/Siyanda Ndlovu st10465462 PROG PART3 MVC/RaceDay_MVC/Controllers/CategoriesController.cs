using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Services;
using RaceDay_MVC.Models;
namespace RaceDay_MVC.Controllers;
public class CategoriesController:Controller
{
 private readonly RaceDayApi _api; public CategoriesController(RaceDayApi api)=>_api=api;
 public async Task<IActionResult> Index(){if(string.IsNullOrEmpty(HttpContext.Session.GetString("Token")))return RedirectToAction("Login","Account");var r=await _api.Send(HttpContext,HttpMethod.Get,"api/Categories");ViewBag.Error=r.error;return View(r.data);}
 [HttpGet] public IActionResult Create(){if(HttpContext.Session.GetString("Role")!="Organiser")return Forbid();return View(new CategoryForm());}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Create(CategoryForm form){if(HttpContext.Session.GetString("Role")!="Organiser")return Forbid();if(!ModelState.IsValid)return View(form);var r=await _api.Send(HttpContext,HttpMethod.Post,"api/Categories",form);if(r.ok)return RedirectToAction(nameof(Index));ViewBag.Error=r.error;return View(form);}
}
