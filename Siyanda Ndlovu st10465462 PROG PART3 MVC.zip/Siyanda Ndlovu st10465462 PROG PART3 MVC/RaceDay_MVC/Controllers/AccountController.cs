using Microsoft.AspNetCore.Mvc;
using RaceDay_MVC.Models;
using RaceDay_MVC.Services;
namespace RaceDay_MVC.Controllers;
public class AccountController : Controller
{
 private readonly RaceDayApi _api; public AccountController(RaceDayApi api) => _api=api;
 [HttpGet] public IActionResult Login()=>View(new LoginForm());
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Login(LoginForm form)
 {
  if(!ModelState.IsValid)return View(form);
  var r=await _api.Send(HttpContext,HttpMethod.Post,"api/Auth/login",form);
  if(!r.ok || r.data == null){ViewBag.Error=r.error;return View(form);}
  HttpContext.Session.SetString("Token",r.data["token"]?.ToString()??"");
  HttpContext.Session.SetString("Role",r.data["role"]?.ToString()??"");
  HttpContext.Session.SetString("Name",r.data["name"]?.ToString()??"");
  HttpContext.Session.SetString("UserId",r.data["userId"]?.ToString()??"");
  return RedirectToAction("Index","Dashboard");
 }
 [HttpGet] public IActionResult Register()=>View(new RegisterForm());
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Register(RegisterForm form)
 {
  if(!ModelState.IsValid)return View(form);
  var r=await _api.Send(HttpContext,HttpMethod.Post,"api/Auth/register",form);
  if(!r.ok){ViewBag.Error=r.error;return View(form);}
  TempData["Message"]="Registration successful. Please log in.";return RedirectToAction(nameof(Login));
 }
 [HttpPost,ValidateAntiForgeryToken] public IActionResult Logout(){HttpContext.Session.Clear();return RedirectToAction("Index","Home");}
}
