using Microsoft.AspNetCore.Mvc;
namespace RaceDay_MVC.Controllers;
public class DashboardController:Controller
{
 public IActionResult Index(){if(string.IsNullOrEmpty(HttpContext.Session.GetString("Token")))return RedirectToAction("Login","Account");return View();}
}
