﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDay.Data;
using RaceDayPOE_part2.Models;
using RaceDayPOE_part2.DTOs;

namespace RaceDayPOE_part2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public ResultsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/Results
        // Participants see their own results.
        // Organisers see results for their own events.
        [HttpGet]
        [Authorize(Roles = "Participant,Organiser")]
        public async Task<IActionResult> GetResults()
        {
            var userIdClaim = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var query =
                from r in _context.Results
                join en in _context.Enrolments
                    on r.enrolment_ID equals en.enrolmentID
                join p in _context.Participants
                    on en.participantID equals p.participant_ID
                join ev in _context.Events
                    on en.event_ID equals ev.event_ID
                select new
                {
                    Result = r,
                    ParticipantUserId = p.user_ID,
                    EventOrganiserId = ev.organiser_ID,
                    EventId = ev.event_ID,
                    EventName = ev.event_name
                };

            if (User.IsInRole("Participant"))
            {
                query = query.Where(x =>
                    x.ParticipantUserId == userId);
            }
            else if (User.IsInRole("Organiser"))
            {
                var organiser = await _context.Organisers
                    .FirstOrDefaultAsync(o => o.user_ID == userId);

                if (organiser == null)
                {
                    return NotFound("Organiser profile not found.");
                }

                query = query.Where(x =>
                    x.EventOrganiserId == organiser.organiser_ID);
            }

            var results = await query
                .Select(x => new
                {
                    x.Result.result_ID,
                    x.Result.position,
                    x.Result.finishingTime,
                    x.Result.enrolment_ID,
                    x.EventId,
                    x.EventName
                })
                .ToListAsync();

            return Ok(results);
        }

        // POST: api/Results
        // Only organisers can record results.
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateResult(
            CreateResultDto dto)
        {
            if (dto.position.HasValue && dto.position.Value < 1)
            {
                return BadRequest(
                    "Position must be greater than zero.");
            }

            var userIdClaim = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.user_ID == userId);

            if (organiser == null)
            {
                return NotFound("Organiser profile not found.");
            }

            var enrolment = await _context.Enrolments
                .FirstOrDefaultAsync(e =>
                    e.enrolmentID == dto.enrolment_ID);

            if (enrolment == null)
            {
                return NotFound("Enrolment not found.");
            }

            var eventBelongsToOrganiser =
                await _context.Events.AnyAsync(e =>
                    e.event_ID == enrolment.event_ID &&
                    e.organiser_ID == organiser.organiser_ID);

            if (!eventBelongsToOrganiser)
            {
                return Forbid(
                    "You can only record results for your own events.");
            }

            var resultExists = await _context.Results
                .AnyAsync(r =>
                    r.enrolment_ID == dto.enrolment_ID);

            if (resultExists)
            {
                return Conflict(
                    "A result already exists for this enrolment.");
            }

            var result = new Result
            {
                enrolment_ID = dto.enrolment_ID,
                position = dto.position,
                finishingTime = dto.finishingTime
            };

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return Created(
                "api/Results",
                new
                {
                    result.result_ID,
                    result.position,
                    result.finishingTime,
                    result.enrolment_ID
                });
        }

        // PUT: api/Results/1
        // Only the organiser responsible for the event can update.
        [HttpPut("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateResult(
            int id, CreateResultDto dto)
        {
            if (dto.position.HasValue && dto.position.Value < 1)
            {
                return BadRequest(
                    "Position must be greater than zero.");
            }

            var userIdClaim = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.user_ID == userId);

            if (organiser == null)
            {
                return NotFound("Organiser profile not found.");
            }

            var result = await _context.Results
                .FirstOrDefaultAsync(r => r.result_ID == id);

            if (result == null)
            {
                return NotFound("Result not found.");
            }

            var enrolment = await _context.Enrolments
                .FirstOrDefaultAsync(e =>
                    e.enrolmentID == result.enrolment_ID);

            if (enrolment == null)
            {
                return NotFound("Enrolment not found.");
            }

            var eventBelongsToOrganiser =
                await _context.Events.AnyAsync(e =>
                    e.event_ID == enrolment.event_ID &&
                    e.organiser_ID == organiser.organiser_ID);

            if (!eventBelongsToOrganiser)
            {
                return Forbid(
                    "You can only update results for your own events.");
            }

            // A result cannot be moved to a different enrolment here.
            result.position = dto.position;
            result.finishingTime = dto.finishingTime;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                result.result_ID,
                result.position,
                result.finishingTime,
                result.enrolment_ID
            });
        }

        // DELETE: api/Results/1
        // Only the organiser responsible for the event can delete.
        [HttpDelete("{id}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteResult(int id)
        {
            var userIdClaim = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.user_ID == userId);

            if (organiser == null)
            {
                return NotFound("Organiser profile not found.");
            }

            var result = await _context.Results
                .FirstOrDefaultAsync(r => r.result_ID == id);

            if (result == null)
            {
                return NotFound("Result not found.");
            }

            var enrolment = await _context.Enrolments
                .FirstOrDefaultAsync(e =>
                    e.enrolmentID == result.enrolment_ID);

            if (enrolment == null)
            {
                return NotFound("Enrolment not found.");
            }

            var eventBelongsToOrganiser =
                await _context.Events.AnyAsync(e =>
                    e.event_ID == enrolment.event_ID &&
                    e.organiser_ID == organiser.organiser_ID);

            if (!eventBelongsToOrganiser)
            {
                return Forbid(
                    "You can only delete results for your own events.");
            }

            _context.Results.Remove(result);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
