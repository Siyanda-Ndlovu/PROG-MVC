﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Data;
using RaceDayPOE_part2.DTOs;
using RaceDayPOE_part2.Models;
namespace RaceDay.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly RaceDayDbContext _context;
        private readonly PasswordHasher<Users> _passwordHasher;

        public AuthController(RaceDayDbContext context)
        {
            _context = context;
            _passwordHasher = new PasswordHasher<Users>();
        }


        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDto request)
        {
            if (string.IsNullOrWhiteSpace(request.Name) ||
                string.IsNullOrWhiteSpace(request.PhoneNumber) ||
                string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Password) ||
                string.IsNullOrWhiteSpace(request.Role))
            {
                return BadRequest("All fields are required.");
            }

            string selectedRole = request.Role.Trim();

            if (selectedRole.Equals(
                    "Participant",
                    StringComparison.OrdinalIgnoreCase))
            {
                selectedRole = "Participant";
            }
            else if (selectedRole.Equals(
                         "Organiser",
                         StringComparison.OrdinalIgnoreCase))
            {
                selectedRole = "Organiser";
            }
            else
            {
                return BadRequest(
                    "Role must be either Participant or Organiser.");
            }

            bool emailExists = await _context.Users
                .AnyAsync(u => u.email == request.Email.Trim());

            if (emailExists)
            {
                return Conflict("This email is already registered.");
            }

            var user = new Users
            {
                name = request.Name.Trim(),
                phoneNumber = request.PhoneNumber.Trim(),
                email = request.Email.Trim(),
                role = selectedRole
            };

            user.password = _passwordHasher.HashPassword(
                user, request.Password);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            if (selectedRole == "Organiser")
            {
                _context.Organisers.Add(new()
                {
                    user_ID = user.user_ID
                });

                await _context.SaveChangesAsync();
            }

            return Ok(new
            {
                Message = "Registration successful.",
                UserId = user.user_ID,
                Name = user.name,
                Email = user.email,
                Role = user.role
            });
        }


        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto request)
        {
            if (string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest("Email and password are required.");
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.email == request.Email.Trim());

            if (user == null)
            {
                return Unauthorized("Invalid email or password.");
            }

            var result = _passwordHasher.VerifyHashedPassword(
                user,
                user.password,
                request.Password
            );

            if (result == PasswordVerificationResult.Failed)
            {
                return Unauthorized("Invalid email or password.");
            }


            var token = GenerateJwtToken(user);


            return Ok(new
            {
                Message = "Login successful.",
                Token = token,
                UserId = user.user_ID,
                Name = user.name,
                Email = user.email,
                Role = user.role
            });


        }


        private string GenerateJwtToken(Users user)
        {
            var jwtKey = HttpContext.RequestServices
                .GetRequiredService<IConfiguration>()["Jwt:Key"]
                ?? throw new InvalidOperationException("JWT Key is missing.");

            var issuer = HttpContext.RequestServices
                .GetRequiredService<IConfiguration>()["Jwt:Issuer"];

            var audience = HttpContext.RequestServices
                .GetRequiredService<IConfiguration>()["Jwt:Audience"];


            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.user_ID.ToString()),
                new Claim(ClaimTypes.Name, user.name),
                new Claim(ClaimTypes.Email, user.email),
                new Claim(ClaimTypes.Role, user.role)
            };


            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(60),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


    }
}
