﻿namespace RaceDayPOE_part2.DTOs
{
    public class CreateResultDto
    {

        public int enrolment_ID { get; set; }

        public int? position { get; set; }

        public TimeOnly? finishingTime { get; set; }

    }
}
