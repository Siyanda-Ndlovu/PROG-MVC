﻿namespace RaceDayPOE_part2.DTOs
{
    public class EnrolmentDto
    {

        public int event_ID { get; set; }

        public int participantID { get; set; }

    }
}
