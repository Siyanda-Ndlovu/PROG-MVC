﻿
using Microsoft.EntityFrameworkCore;
//using RaceDay.Models;
using RaceDayPOE_part2.Models;

namespace RaceDay.Data
{
    public class RaceDayDbContext : DbContext
    {
        public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options)
            : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
        public DbSet<Organiser> Organisers { get; set; }
        public DbSet<Participant> Participants { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Enrolment> Enrolments { get; set; }
        public DbSet<Result> Results { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Users>().ToTable("Users");
            modelBuilder.Entity<Organiser>().ToTable("Organiser");
            modelBuilder.Entity<Participant>().ToTable("Participant");
            modelBuilder.Entity<Event>().ToTable("Event");
            modelBuilder.Entity<Category>().ToTable("Category");
            modelBuilder.Entity<Enrolment>().ToTable("Enrolment");
            modelBuilder.Entity<Result>().ToTable("Result");

            modelBuilder.Entity<Users>().HasKey(u => u.user_ID);
            modelBuilder.Entity<Organiser>().HasKey(o => o.organiser_ID);
            modelBuilder.Entity<Participant>().HasKey(p => p.participant_ID);
            modelBuilder.Entity<Event>().HasKey(e => e.event_ID);
            modelBuilder.Entity<Category>().HasKey(c => c.category_ID);
            modelBuilder.Entity<Enrolment>().HasKey(e => e.enrolmentID);
            modelBuilder.Entity<Result>().HasKey(r => r.result_ID);

            modelBuilder.Entity<Users>()
                .Property(u => u.name)
                .IsRequired();

            modelBuilder.Entity<Users>()
                .Property(u => u.phoneNumber)
                .IsRequired();

            modelBuilder.Entity<Users>()
                .Property(u => u.email)
                .IsRequired();

            modelBuilder.Entity<Users>()
                .Property(u => u.password)
                .IsRequired();

            // Organiser belongs to a user
            modelBuilder.Entity<Organiser>()
                .HasOne<Users>()
                .WithMany()
                .HasForeignKey(o => o.user_ID);

            // Participant belongs to a user
            modelBuilder.Entity<Participant>()
                .HasOne<Users>()
                .WithMany()
                .HasForeignKey(p => p.user_ID);

            // Event belongs to an organiser
            modelBuilder.Entity<Event>()
                .HasOne<Organiser>()
                .WithMany()
                .HasForeignKey(e => e.organiser_ID);

            // Event belongs to a category
            modelBuilder.Entity<Event>()
                .HasOne<Category>()
                .WithMany()
                .HasForeignKey(e => e.category_ID);

            // Enrolment belongs to an event
            modelBuilder.Entity<Enrolment>()
                .HasOne<Event>()
                .WithMany()
                .HasForeignKey(e => e.event_ID);

            // Enrolment belongs to a participant
            modelBuilder.Entity<Enrolment>()
                .HasOne<Participant>()
                .WithMany()
                .HasForeignKey(e => e.participantID);

            // Result belongs to an enrolment
            modelBuilder.Entity<Result>()
                .HasOne<Enrolment>()
                .WithMany()
                .HasForeignKey(r => r.enrolment_ID);

        }
    }
}
