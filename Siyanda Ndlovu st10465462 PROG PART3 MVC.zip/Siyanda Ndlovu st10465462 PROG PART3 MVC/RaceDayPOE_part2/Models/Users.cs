﻿namespace RaceDayPOE_part2.Models
{
    public class Users
    {
        public int user_ID { get; set; }

        public string name { get; set; } = string.Empty;

        public string phoneNumber { get; set; } = string.Empty;

        public string email { get; set; } = string.Empty;

        public string password { get; set; } = string.Empty;

        public string role { get; set; } = "Participant";
    }
}
