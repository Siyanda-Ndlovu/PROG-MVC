﻿
namespace RaceDayPOE_part2.Models
{
    public class Category
    {
        public int category_ID { get; set; }

        public string? categoryName { get; set; }

        public decimal? distance { get; set; }

        public TimeOnly? StartTime { get; set; }

        public int? event_ID { get; set; }

        public int? organiser_ID { get; set; }
    }
}
