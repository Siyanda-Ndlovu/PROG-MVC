﻿namespace RaceDayPOE_part2.Models
{
    public class Enrolment
    {
        public int enrolmentID { get; set; }
        public DateOnly enrolmentDate { get; set; }
        public int event_ID { get; set; }
        public int participantID { get; set; }
    }
}
