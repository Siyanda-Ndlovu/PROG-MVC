﻿namespace RaceDayPOE_part2.Models
{
    public class Result
    {
        public int result_ID { get; set; }

        public int? position { get; set; }

        public TimeOnly? finishingTime { get; set; }

        public int enrolment_ID { get; set; }

    }
}
