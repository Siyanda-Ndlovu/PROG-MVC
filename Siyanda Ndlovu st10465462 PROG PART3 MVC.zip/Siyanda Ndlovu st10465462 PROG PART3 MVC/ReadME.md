# RaceDay Part 3 — API 7271 + MVC 7259

Open `RaceDayPOE_part2/RaceDayPOE_part2.slnx` in Visual Studio 2022 (17.12 or newer for .slnx).

1. Restore NuGet packages. Ensure .NET 8 SDK and ASP.NET web development workload are installed.
2. Set **multiple startup projects**: `RaceDayPOE_part2` = Start, `RaceDay_MVC` = Start. Choose HTTPS profiles.
3. Set the SQL Server connection string in `RaceDayPOE_part2/appsettings.json` for your own SQL Server. Never commit real secrets. The original API and schema have been retained.
4. Run F5. API Swagger: https://localhost:7271/swagger ; MVC homepage: https://localhost:7259/ .
5. `RaceDay_MVC/appsettings.json` -> `ApiSettings:BaseUrl` = `https://localhost:7271/`.

## Scope and limitations
This archive combines the original API from your MVC.zip with the expanded MVC frontend from the previous revision. The original API endpoints are unchanged. The API currently lacks an event DELETE endpoint, does not provide category selection on enrolment, and its participant enrolment requires an existing participant record for the selected event. Therefore these functions cannot be claimed fully working. The project has NOT been built or run in this environment because the .NET SDK is unavailable. Azure Blob Storage and Docker rubric requirements are not implemented. Test locally before submission.
